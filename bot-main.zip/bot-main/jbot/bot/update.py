version = 'version :1.0.0.0'
botlog = '''
**2021年9月24日**
本次更新内容如下:
    - 新增 /userlogin /codelogin
        codelogin 测试过了没问题，
        userlogin 摄像头坏了没办法测试，自行测试吧
        使用二维码/验证码 登录tguser
        配合 /set ‘开启user’ 可以开启tg用户登录
    - 几个user功能 id、del re
        回复id 得到id
        del n 删除n条消息
        re n 转发n条消息
    - 新增 /reboot 重启机器人
    - 新增 /aff 来杯肥宅快乐水
    - NEW BUG...
'''

